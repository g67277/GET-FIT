//
//  WorkoutMinutes.h
//  GET FIT
//
//  Created by Nazir Shuqair on 8/21/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface WorkoutMinutes : NSManagedObject

@property (nonatomic, retain) NSNumber * minutes;

@end
