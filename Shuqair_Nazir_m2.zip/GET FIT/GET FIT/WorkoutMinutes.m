//
//  WorkoutMinutes.m
//  GET FIT
//
//  Created by Nazir Shuqair on 8/21/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import "WorkoutMinutes.h"


@implementation WorkoutMinutes

@dynamic minutes;

@end
