//
//  settings.m
//  GET FIT
//
//  Created by Nazir Shuqair on 8/17/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import "settings.h"

@implementation settings
@synthesize restCount;

@end
