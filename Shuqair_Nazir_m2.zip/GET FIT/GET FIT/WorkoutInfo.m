//
//  WorkoutInfo.m
//  GET FIT
//
//  Created by Nazir Shuqair on 8/10/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import "WorkoutInfo.h"

@implementation WorkoutInfo
@synthesize imageArray, title, workoutTag;

@end
