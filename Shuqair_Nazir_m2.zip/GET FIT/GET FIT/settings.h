//
//  settings.h
//  GET FIT
//
//  Created by Nazir Shuqair on 8/17/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface settings : NSObject

@property (nonatomic, assign) int restCount;

@end
